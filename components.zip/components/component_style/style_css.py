"""
CSS for custom styling

Author: Abhishek Gupta
Github: https://github.com/1abhi6
"""

PADDING_TOP = """
<style>
        .main > div {
            padding-top: 2rem;
            padding-bottom: 2rem;
        }
    </style>
"""
