"""
CSS for custom styling

Github: https://github.com/joshikartik26/streamlit-project
"""

PADDING_TOP = """
<style>
        .main > div {
            padding-top: 2rem;
            padding-bottom: 2rem;
        }
    </style>
"""
