"""
Github:https://github.com/joshikartik26/streamlit-project
"""

from components.investor import Investor
from components.overall import Overall
from components.startup import Startup
from components.component_style.style_css import PADDING_TOP
